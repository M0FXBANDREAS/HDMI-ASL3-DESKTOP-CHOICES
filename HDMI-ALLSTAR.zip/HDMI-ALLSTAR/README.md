# HDMI ALLSTAR

Project for HamTec / M0FXB Andreas. Saved 3 October 2026.

## Target system
Raspberry Pi 3B, ASL3 appliance on Debian 12 Bookworm.
Linux user: allstar3. Node: 539017. Local IP: 192.168.0.100.
Allmon3 is already installed and responds at /allmon3/.

## Included scripts, in installation order
1. asl3-hdmi-install.sh: installs Chromium, Xorg and Openbox; enables asl3-hdmi.service.
2. asl3-hdmi-buttons.sh: adds three dashboard-selection buttons (optional if installing the desktop update next).
3. asl3-hdmi-desktop.sh: adds larger coloured buttons plus PCManFM, LXPanel and LXTerminal. Requires step 1.

Run each chosen installer on the Pi with sudo bash followed by its filename.
The first installer can be run as:
    sudo bash asl3-hdmi-install.sh allstar3

## Confirmed working fix
The initial HDMI display showed a white screen. Adding --disable-gpu to the Chromium command in /usr/local/bin/asl3-hdmi-session resolved it. The user confirmed the Allmon3 HDMI display worked.
The initial installer in this archive predates that fix. After step 1, run the desktop update (which applies the fix), or apply it manually:
    sudo sed -i 's/--kiosk/--kiosk --disable-gpu/' /usr/local/bin/asl3-hdmi-session
    sudo systemctl restart asl3-hdmi.service

## Desktop update
Green: Connections - http://192.168.0.100/allmon3/
Blue: Main Dashboard - http://192.168.0.100/
Orange: System :9090 - http://192.168.0.100:9090/
Purple: Desktop - minimises Chromium to expose the desktop.
A dashboard button restores Chromium. The desktop has Files, Terminal and a bottom application menu.
Dashboard URLs are specific to this Pi. Other users must change them.
Syntax and session-patching tests passed. User confirmation of the final desktop/button layout has not yet been recorded.

## GitHub hosting
https://github.com/M0FXBANDREAS/HDMI-ASL3-DESKTOP-CHOICES
Last verified repository filename: asl3-hdmi-desktop (1).sh, branch main.
Download/update command:
    wget -O /tmp/asl3-hdmi-desktop.sh 'https://raw.githubusercontent.com/M0FXBANDREAS/HDMI-ASL3-DESKTOP-CHOICES/main/asl3-hdmi-desktop%20%281%29.sh' && sudo bash /tmp/asl3-hdmi-desktop.sh
This is an update, not a standalone clean installation. GitHub contents may change after this archive is saved.

## Copy from Windows
Download the chosen script into C:\Users\andre\Downloads, then use PowerShell:
    scp "C:\Users\andre\Downloads\asl3-hdmi-desktop.sh" allstar3@192.168.0.100:~/
Then in the Pi SSH terminal:
    sudo bash ~/asl3-hdmi-desktop.sh

## Service commands
Logs:
    sudo journalctl -u asl3-hdmi.service -n 60 --no-pager
Restart display:
    sudo systemctl restart asl3-hdmi.service
Disable display:
    sudo systemctl disable --now asl3-hdmi.service

Installers make backups under /var/backups/asl3-hdmi*.
Reboot interrupts AllStar connections. Adding a desktop does not replace ASL3 with Raspberry Pi OS.
