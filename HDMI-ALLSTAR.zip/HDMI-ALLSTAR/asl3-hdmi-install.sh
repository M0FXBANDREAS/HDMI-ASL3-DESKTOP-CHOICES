#!/bin/bash
# ASL3 Allmon3 HDMI kiosk installer v1.0.0
# Debian 12 Bookworm, Raspberry Pi; existing configured Allmon3 required.
set -Eeuo pipefail
fail() { printf 'ERROR: %s\n' "$*" >&2; exit 1; }
if [[ ${1:-} == --help ]]; then
  echo 'Usage: sudo bash asl3-hdmi-install.sh [desktop-user]'
  echo 'Default user: original sudo user, or allstar3.'
  exit 0
fi
[[ $EUID == 0 ]] || fail 'Run with sudo bash asl3-hdmi-install.sh'
[[ $# -le 1 ]] || fail 'Expected at most one desktop username.'
desktop_user=${1:-${SUDO_USER:-allstar3}}
[[ $desktop_user =~ ^[a-z_][a-z0-9_-]*$ && $desktop_user != root ]] || fail 'Choose a normal Linux user.'
user_record=$(getent passwd "$desktop_user") || fail "User $desktop_user does not exist."
IFS=: read -r _ _ desktop_uid _ _ desktop_home _ <<<"$user_record"
[[ $desktop_uid -gt 0 && -d $desktop_home ]] || fail 'User needs a valid home directory.'
. /etc/os-release
[[ ${ID:-} == debian && ${VERSION_CODENAME:-} == bookworm ]] || fail 'This installer supports Debian 12 Bookworm only.'
[[ -r /proc/device-tree/model ]] || fail 'Raspberry Pi hardware not detected.'
grep -aq 'Raspberry Pi' /proc/device-tree/model || fail 'Raspberry Pi hardware required.'
dpkg-query -W -f='${Status}' allmon3 2>/dev/null | grep -q '^install ok installed$' || fail 'Install and configure Allmon3 first.'
command -v curl >/dev/null || fail 'curl is required for the local dashboard check.'
command -v systemctl >/dev/null || fail 'systemd is required.'
[[ $(curl -s -o /dev/null -w '%{http_code}' --max-time 10 http://127.0.0.1/allmon3/) == 200 ]] || fail 'Local Allmon3 page is not responding with HTTP 200.'
if systemctl is-active --quiet display-manager.service; then
  fail 'An existing graphical desktop is running. Use its kiosk setup or stop it before installing this standalone display service.'
fi
[[ ! -S /tmp/.X11-unix/X0 ]] || fail 'An X display is already using :0.'
trap 'echo "Installation failed. Check the error above. Collect logs with: sudo journalctl -u asl3-hdmi.service -n 60 --no-pager" >&2' ERR
printf 'Installing HDMI display packages for %s. This can take several minutes...\n' "$desktop_user"
apt-get update
apt-get install -y --no-install-recommends xserver-xorg xserver-xorg-legacy xinit xauth openbox chromium x11-xserver-utils dbus-x11 fonts-dejavu-core
for executable in /usr/bin/startx /usr/lib/xorg/Xorg /usr/bin/chromium /usr/bin/dbus-run-session /usr/bin/xhost /usr/sbin/runuser; do
  [[ -x $executable ]] || fail "Required program missing: $executable"
done
backup=$(mktemp -d /var/backups/asl3-hdmi.XXXXXXXX)
chmod 700 "$backup"
for target in /usr/local/bin/asl3-hdmi-session /etc/systemd/system/asl3-hdmi.service /etc/default/asl3-hdmi; do
  [[ ! -e $target ]] || cp -a --parents "$target" "$backup/"
done
systemctl is-enabled asl3-hdmi.service >"$backup/previous-enabled.txt" 2>&1 || true
systemctl stop asl3-hdmi.service 2>/dev/null || true
# Bash-quoted settings are read by the root-owned session script.
printf 'KIOSK_USER=%q\nKIOSK_HOME=%q\nKIOSK_URL=%q\n' "$desktop_user" "$desktop_home" 'http://127.0.0.1/allmon3/' >/etc/default/asl3-hdmi
chmod 644 /etc/default/asl3-hdmi
cat >/usr/local/bin/asl3-hdmi-session <<'SESSION'
#!/bin/bash
set -Eeuo pipefail
. /etc/default/asl3-hdmi
xset s off
xset s noblank
xset -dpms || true
xhost "+SI:localuser:$KIOSK_USER"
# A dedicated persistent browser profile preserves local dashboard preferences.
profile="$KIOSK_HOME/.local/share/asl3-hdmi-chromium"
runuser -u "$KIOSK_USER" -- mkdir -p "$profile"
openbox &
# Wait for Apache after boot. Exit on timeout so systemd can retry.
ready=0
for attempt in {1..60}; do
  if [[ $(curl -s -o /dev/null -w '%{http_code}' --max-time 2 "$KIOSK_URL") == 200 ]]; then
    ready=1
    break
  fi
  sleep 2
done
(( ready )) || { echo 'Allmon3 did not become ready.' >&2; exit 1; }
exec runuser -u "$KIOSK_USER" -- env HOME="$KIOSK_HOME" DISPLAY="$DISPLAY" XAUTHORITY=/dev/null \
  dbus-run-session -- chromium --user-data-dir="$profile" --kiosk \
  --no-first-run --no-default-browser-check --disable-session-crashed-bubble "$KIOSK_URL"
SESSION
chmod 755 /usr/local/bin/asl3-hdmi-session
cat >/etc/systemd/system/asl3-hdmi.service <<'SERVICE'
[Unit]
Description=ASL3 Allmon3 HDMI dashboard
After=network.target apache2.service
StartLimitIntervalSec=300
StartLimitBurst=5

[Service]
Type=simple
RuntimeDirectory=asl3-hdmi-x
RuntimeDirectoryMode=0700
Environment=HOME=/run/asl3-hdmi-x
WorkingDirectory=/run/asl3-hdmi-x
ExecStart=/usr/bin/startx /usr/local/bin/asl3-hdmi-session -- /usr/lib/xorg/Xorg :0 vt7 -nolisten tcp -logfile /run/asl3-hdmi-x/Xorg.log
Restart=on-failure
RestartSec=15
KillMode=control-group
Nice=10

[Install]
WantedBy=multi-user.target
SERVICE
systemctl daemon-reload
systemctl reset-failed asl3-hdmi.service || true
systemctl enable --now asl3-hdmi.service
printf '\nHDMI service started and enabled at boot. Backup: %s\n' "$backup"
echo 'Check the HDMI monitor: Allmon3 should open full-screen.'
echo 'Select node 539017 in Allmon3 if it is not already displayed.'
echo 'HTTP 200 and a started service do not confirm live node data or HDMI output.'
echo 'Logs: sudo journalctl -u asl3-hdmi.service -n 60 --no-pager'
echo 'Stop/disable: sudo systemctl disable --now asl3-hdmi.service'
echo 'Restart: sudo systemctl restart asl3-hdmi.service'
