#!/bin/bash
# Add a persistent dashboard selector to the existing ASL3 HDMI installation.
set -Eeuo pipefail
[[ $EUID == 0 ]] || { echo 'Run: sudo bash asl3-hdmi-buttons.sh'; exit 1; }
[[ -f /usr/local/bin/asl3-hdmi-session && -f /etc/default/asl3-hdmi ]] || { echo 'Install the ASL3 HDMI service first.'; exit 1; }
apt-get update
apt-get install -y --no-install-recommends python3-tk xdotool x11-utils
backup=$(mktemp -d /var/backups/asl3-hdmi-buttons.XXXXXXXX)
cp -a /usr/local/bin/asl3-hdmi-session "$backup/"
systemctl stop asl3-hdmi.service
cat >/usr/local/bin/asl3-hdmi-buttons <<'PY'
#!/usr/bin/python3
import subprocess
import tkinter as tk

PAGES = [
    ('Connections', 'http://192.168.0.100/allmon3/'),
    ('Main Dashboard', 'http://192.168.0.100/'),
    ('System :9090', 'http://192.168.0.100:9090/'),
]
root = tk.Tk()
root.title('ASL3 Dashboard Selector')
root.configure(bg='#10293d')
root.attributes('-type', 'dock')
root.attributes('-topmost', True)
height = 66
width = root.winfo_screenwidth()
root.geometry(f'{width}x{height}+0+0')
root.resizable(False, False)
status = tk.StringVar(value='Choose a dashboard')
buttons = []

def switch(index):
    # Search only mapped browser windows. Never send keys to the terminal.
    try:
        result = subprocess.run(
            ['xdotool', 'search', '--onlyvisible', '--class', 'chromium'],
            capture_output=True, text=True, timeout=3, check=True)
        windows = result.stdout.split()
        if not windows:
            raise RuntimeError('Browser is not ready')
        window = windows[0]
        subprocess.run(['xdotool', 'windowactivate', '--sync', window],
                       timeout=3, check=True)
        subprocess.run(['xdotool', 'key', '--clearmodifiers', 'ctrl+l'],
                       timeout=3, check=True)
        subprocess.run(['xdotool', 'type', '--clearmodifiers', '--delay', '1', PAGES[index][1]],
                       timeout=3, check=True)
        subprocess.run(['xdotool', 'key', '--clearmodifiers', 'Return'],
                       timeout=3, check=True)
        for n, button in enumerate(buttons):
            button.configure(bg='#007f85' if n == index else '#24465f')
        status.set(PAGES[index][0])
    except Exception:
        status.set('Browser starting - try again')

for i, (label, _) in enumerate(PAGES):
    button = tk.Button(root, text=label, font=('DejaVu Sans', 13, 'bold'),
                       fg='white', bg='#24465f', activebackground='#007f85',
                       activeforeground='white', relief='flat', padx=12,
                       command=lambda n=i: switch(n))
    button.pack(side='left', fill='both', expand=True, padx=5, pady=8)
    buttons.append(button)

# Reserve the top strip so Openbox maximizes Chromium below the buttons.
def reserve():
    root.update_idletasks()
    window = root.wm_frame()
    subprocess.run(['xprop', '-id', window, '-f', '_NET_WM_STRUT', '32c',
                    '-set', '_NET_WM_STRUT', f'0, 0, {height}, 0'], check=True)
    values = f'0, 0, {height}, 0, 0, 0, 0, 0, 0, {width-1}, 0, 0'
    subprocess.run(['xprop', '-id', window, '-f', '_NET_WM_STRUT_PARTIAL', '32c',
                    '-set', '_NET_WM_STRUT_PARTIAL', values], check=True)
root.after(300, reserve)
root.mainloop()
PY
chmod 755 /usr/local/bin/asl3-hdmi-buttons
python3 - <<'PY'
from pathlib import Path
p=Path('/usr/local/bin/asl3-hdmi-session')
s=p.read_text()
s=s.replace('--kiosk', '--start-maximized')
if '--disable-gpu' not in s:
    s=s.replace('--start-maximized', '--start-maximized --disable-gpu')
marker='exec runuser -u "$KIOSK_USER" -- env'
launch='runuser -u "$KIOSK_USER" -- env HOME="$KIOSK_HOME" DISPLAY="$DISPLAY" XAUTHORITY=/dev/null /usr/local/bin/asl3-hdmi-buttons &\n'
if '/usr/local/bin/asl3-hdmi-buttons &' not in s:
    if marker not in s:
        raise SystemExit('Unrecognized session file. Restore the backup and ask for help.')
    s=s.replace(marker, launch+marker, 1)
p.write_text(s)
PY
bash -n /usr/local/bin/asl3-hdmi-session
systemctl start asl3-hdmi.service
printf '\nThree dashboard buttons installed. Previous session: %s/asl3-hdmi-session\n' "$backup"
echo 'Wait for the browser, then click Connections, Main Dashboard, or System :9090.'
echo 'The 9090 dashboard may redirect to HTTPS or require a login.'
echo 'Logs: sudo journalctl -u asl3-hdmi.service -n 60 --no-pager'
